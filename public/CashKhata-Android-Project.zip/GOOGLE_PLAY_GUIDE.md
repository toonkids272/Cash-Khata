# 🚀 How to Build Google Play Package (.AAB) in Android Studio

This project is 100% pre-configured for Google Play Store publication with your official package name, icons, and AdMob IDs.

---

### Step 1: Open the Project in Android Studio
1. Download and extract **`CashKhata-Android-Project.zip`**.
2. Open **Android Studio** and click **File > Open...**.
3. Select the extracted folder and let Gradle sync.

---

### Step 2: Build Google Play Store Bundle (.AAB)
1. In Android Studio's top menu, click:
   **Build > Generate Signed Bundle / APK...**
2. Choose **Android App Bundle** and click **Next**.
3. Under **Key store path**, click **Create new...**:
   - Choose a location on your computer to save your `.jks` keystore file.
   - Enter a password and Alias (e.g., `cashkhata_key`).
   - Fill in your name/organization.
   - Click **OK**.
4. Select **release** build variant and click **Create**.
5. Your Google Play `.aab` file will be generated in:
   `app/release/app-release.aab`
6. Upload this **`app-release.aab`** directly to **Google Play Console**!

---

### Step 3: Build Debug APK for Testing (.APK)
If you want to install and test on your Android phone immediately:
1. In Android Studio, click:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)**
2. The `.apk` will be output to:
   `app/build/outputs/apk/debug/app-debug.apk`
3. Sideload it onto any Android phone and install!

---

### App Identity & AdMob Verification
- **Package Name**: `com.cashkhata.vyaparledger`
- **Application ID**: `ca-app-pub-2290313694944386~9326363627`
- **Target SDK**: `34` (Android 14 - compliant with Google Play target API policy)
